﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elevator : MonoBehaviour
{
    float downDir;
    float stopPoint;

    bool cardKey = false;

    //public GameObject elevator;
    public GameObject Player;

    private Rigidbody rbEle;

    // Start is called before the first frame update
    void Start()
    {
        rbEle.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter(Collider coll)
    {
        //downDir = coll.gameObject.GetComponent<Transform>().position.y;

        //while (downDir > downDir - 1.0f)      // 여기에 월드 좌표 놔주기 

        // if(coll.tag == "Player" && cardKey == true)       // 나중에 플레이어에 태그 붙이고 주석 해제할 것.
        {
            coll.gameObject.GetComponent<Rigidbody>().AddForce(Vector3.down * 2.0f);    // 속도는 알맞게 조절
            GetComponent<Rigidbody>().AddForce(Vector3.down * 2.0f);
            // Debug.Log(coll.gameObject.name);
        }

        // 나중에 AI가 엘리베이터를 움직일수도 있게 해보자
    }

    //void OnTriggerExit(Collider other)
    //{
    //    downDir -= 1.0f;
    //}
}
